import java.util.Scanner;

public class Inicial {
	public static void main(String args[]) {
		int i = 50;
		boolean exit = false;
		int control;
		
		Scanner input = new Scanner(System.in);
		
		while(!exit) {
			control = input.nextInt();
			System.out.println("1 - Entrar com dados de um novo funcionario");
			System.out.print("Digite um Commando: ");
			switch(control) {
			case 1:
				break;
			case 2:
				break;
			case 3:
				break;
			case -1:
				break;
			default:
				System.out.println("Valor Invalido!");
			}
		}
		
		input.close();
	}
	

}
