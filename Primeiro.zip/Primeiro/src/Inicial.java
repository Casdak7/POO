
public class Inicial {
	public static void main(String args[]) {
		Data aniversario = new Data();
		
		
		System.out.println(aniversario.toString());
	}
	

}
