
public class Funcionario extends Pessoa {

	private Data dataAdmissao;
	private float salario;
	
	Funcionario(String nome, String identidade, Data dataNascimento, Data dataAdmissao, float salario) {
		super(nome, identidade, dataNascimento);
		this.setDataAdmissao(dataAdmissao);
		this.setSalario(salario);
	}
	
	public Data getDataAdmissao() {
		return dataAdmissao;
	}
	
	public void setDataAdmissao(Data dataAdmissao) {
		this.dataAdmissao = dataAdmissao;
	}

	public float getSalario() {
		return salario;
	}

	public void setSalario(float salario) {
		this.salario = salario;
	}
	
	public String toString() {
		StringBuilder newString = new StringBuilder();
		newString.append(super.toString()).append("\nData de Admissao: ").append(this.dataAdmissao.toString()).append("\nSalario: ").append(this.salario);
		return newString.toString();
	}
	
	public void reajustarSalario(float taxa) {
		float newSalario = this.salario + (this.salario * taxa);
		
		this.setSalario(newSalario);
	}
	
	@Override
	public float calculaLimiteEmprestimo() {
		return this.getSalario();
	}
}
